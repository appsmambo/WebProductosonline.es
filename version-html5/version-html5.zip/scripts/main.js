$(document).ready(function() {
	$('.cerrar').click(function() {
		$('#cookies-alert').fadeOut('slow');
	});
});
